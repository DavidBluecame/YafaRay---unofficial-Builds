Remember to unpack textures!

The YafaRay User's Guide test files by www.yafaray.org is licensed under a Creative Commons Attribution-Share Alike 3.0 Unported License.
Permissions beyond the scope of this license may be available at www.yafaray.org. 